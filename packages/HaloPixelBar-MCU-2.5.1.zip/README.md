# Halo PixelBar MCU 2.5.1 工程包

当前镜像：firmware/hpl2-color/mcu-hpl2-color.bin。
SHA256：9a1b6d1425e980ca1bf9753e0dc1c7ef5ffefde95c741c9a6cf797ace5da237e。

请先阅读 docs/FIRMWARE.md，原理文档从 docs/README.md 开始。
本包包含镜像、校验、补丁源码、离线报告、实验基线和受备份/身份检查约束的更新脚本。
不含原厂完整包、本机安装身份或备份；不是双击即可通用刷机的安装器。
安装开发依赖后可按文档离线重建。更新需自行准备已核对的原厂镜像和本机记录。
Python 旧版和 C# 源码供参考；本固件包省略 native/ 温度组件，桌面应用请下载单独的 C# Windows 包。
不会在解压时自动运行任何程序。显示 MCU 完全失效后的独立 USB 救砖仍未验证。
